for k,v in pairs(configs()) do
  cprint(k)
  cprint(':')
  cprint(v)
  cprint("\n")
end
