bmpprint(0,0,"First line");
msleep(1000)
bmpprint(20,0,"Second line");
msleep(1000)
bmpprint(40,0,"Third line");
msleep(1000)
bmpprint(60,0,"Fourth line");
msleep(1000)
bmpprint(80,0,"Fifth line");
msleep(1000)
bmpprint(100,0,"Sixth line");
